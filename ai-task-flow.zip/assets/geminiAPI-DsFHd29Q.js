const w=["gemini-2.5-flash","gemini-2.5-flash-lite","gemini-2.0-flash-exp","gemini-1.5-flash","gemini-1.5-pro"];async function E(m){try{const a=await fetch(`https://generativelanguage.googleapis.com/v1beta/models?key=${m}`);if(!a.ok)return console.warn("モデル一覧取得エラー: デフォルトリストを使用します"),w;const c=(await a.json()).models||[],l=c.map(e=>e.name.replace("models/","")).filter(e=>{var s;const r=c.find(n=>n.name.endsWith(e));return(s=r==null?void 0:r.supportedGenerationMethods)==null?void 0:s.includes("generateContent")});console.log("APIから取得可能なモデル:",l);const i=[],o=new Set;for(const e of w){if(o.has(e))continue;const r=l.find(s=>s===e||s.startsWith(e));r&&!o.has(r)?(i.push(r),o.add(r)):l.includes(e)&&(i.push(e),o.add(e))}for(const e of l)o.has(e)||(i.push(e),o.add(e));return i.length===0?w:(console.log("使用予定のモデルリスト（優先順）:",i),i)}catch(a){return console.error("モデル取得エラー:",a),w}}const O=async(m,a,f={})=>{if(!m)throw new Error("APIキーが設定されていません");if(!a.trim())throw new Error("タスクを入力してください");const{preferredModel:c,autoSwitch:l=!0,onModelSwitch:i}=f,o=await E(m);let e=[];if(c){const s=o.filter(n=>n!==c);e=[c,...s]}else e=o;l||(e=[e[0]]);let r=null;for(const s of e)try{console.log(`モデル ${s} で実行中...`);const n=await x(m,a,s);return s!==e[0]&&i&&i(s),n}catch(n){if(r=n,!l)throw n;if(n.message.includes("429")||n.message.includes("Quota exceeded")||n.message.includes("503")||n.message.includes("Overloaded")||n.message.includes("404")||n.message.includes("not found")||n.message.includes("not supported")){console.warn(`モデル ${s} でエラーが発生しました (Retryable): ${n.message}. 次のモデルを試します。`);continue}throw n}throw r||new Error("全てのモデルでリクエストが失敗しました")},x=async(m,a,f)=>{var A;const c=`https://generativelanguage.googleapis.com/v1beta/models/${f}:generateContent?key=${m}`,i={contents:[{parts:[{text:`あなたはタスク管理の専門家です。与えられたタスクを分析し、実行可能なサブタスクに分解してください。

【タスク分解のルール - 重要】
1. 各サブタスクの推定所要時間は必ず30分以下にする（厳守）
2. 推定所要時間が30分を超えるタスクは、必ず複数のサブタスクに分割する（例外なし）
3. 各サブタスクは独立して実行可能な単位にする
4. タスクの性質上、分解が困難な場合でも、30分を超える場合は必ず分割する

【タスク分解の判断基準】
- 30分以下のタスク → 1つのサブタスク（分解しない）
- 30分を超えるタスク → 必ず2個以上のサブタスクに分割（各サブタスクは30分以下）
- 60分のタスク → 2-3個のサブタスクに分割（各サブタスクは30分以下）
- 90分のタスク → 3-4個のサブタスクに分割（各サブタスクは30分以下）

【各サブタスクに必要な情報】
- name: タスク名（具体的で実行可能な内容）
- urgency: 緊急度（1=低、2=中、3=高、4=最優先）
- importance: 重要度（1=低、2=中、3=高、4=重要、5=最重要）
- contextKey: 作業環境（Gmail/Drive/DeployConsole/Noneのいずれか）
- estimatedTime: 推定所要時間（分単位、1-30の範囲、各サブタスクは必ず30分以下）
- keywords: 関連キーワード（配列形式、3-5個程度）

【出力形式】
- JSON形式のみを返す
- コードブロック（\`\`\`jsonなど）は使用しない
- 説明文やコメントは一切含めない
- 純粋なJSONオブジェクトのみを返す

【出力例 - 30分を超えるタスクの場合】
{
  "parentTaskName": "Jurise-128の制約変更",
  "subTasks": [
    {
      "name": "Jurise-128の制約変更要件を確認する",
      "urgency": 3,
      "importance": 4,
      "contextKey": "None",
      "estimatedTime": 20,
      "keywords": ["Jurise-128", "制約", "要件確認"]
    },
    {
      "name": "Jurise-128の制約変更の実装計画を立てる",
      "urgency": 3,
      "importance": 4,
      "contextKey": "None",
      "estimatedTime": 25,
      "keywords": ["Jurise-128", "制約", "計画", "設計"]
    },
    {
      "name": "Jurise-128の制約変更を実装する",
      "urgency": 3,
      "importance": 5,
      "contextKey": "None",
      "estimatedTime": 30,
      "keywords": ["Jurise-128", "制約", "実装", "開発"]
    }
  ]
}

タスク: ${a}

JSONのみ返す。`}]}],generationConfig:{temperature:.3,topK:40,topP:.95,maxOutputTokens:3072}},o=await fetch(c,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(i)});if(!o.ok){const t=await o.json().catch(()=>({})),g=((A=t.error)==null?void 0:A.message)||`APIエラー: ${o.status} ${o.statusText}`;throw console.error("Gemini API エラー詳細:",{status:o.status,statusText:o.statusText,error:t,modelName:f}),new Error(g)}const e=await o.json();if(console.log("Gemini APIレスポンス全体:",JSON.stringify(e,null,2)),!e.candidates||!e.candidates[0])throw console.error("Gemini APIレスポンス:",JSON.stringify(e,null,2)),new Error("Gemini APIからの応答にcandidatesがありません");const r=e.candidates[0];if(r.finishReason&&r.finishReason!=="STOP"){if(console.warn("finishReason:",r.finishReason),r.finishReason==="SAFETY")throw new Error("コンテンツが安全性フィルターによってブロックされました");if(r.finishReason==="MAX_TOKENS")throw new Error("レスポンスが最大トークン数に達しました。より短いタスクを入力するか、サブタスクの数を減らしてください。")}if(!r.content)throw console.error("Gemini APIレスポンス:",JSON.stringify(e,null,2)),new Error("Gemini APIからの応答にcontentがありません");const s=r.content;if(!s.parts||!Array.isArray(s.parts)||s.parts.length===0)throw r.finishReason==="MAX_TOKENS"?new Error("レスポンスが最大トークン数に達しました。より短いタスクを入力するか、サブタスクの数を減らしてください。"):(console.error("Gemini APIレスポンス:",JSON.stringify(e,null,2)),console.error("content構造:",JSON.stringify(s,null,2)),new Error("Gemini APIからの応答にpartsがありません"));const n=s.parts[0];let d;if(n.text)d=n.text;else if(n.functionCall)d=JSON.stringify(n.functionCall.args||{});else throw console.error("parts[0]構造:",JSON.stringify(n,null,2)),new Error("Gemini APIからの応答にtextまたはfunctionCallがありません");console.log("Gemini API応答テキスト:",d.substring(0,500));let u;try{let t=d.trim();const g=t.match(/```(?:json)?\s*([\s\S]*?)\s*```/);g&&(t=g[1].trim());const y=t.indexOf("{");if(y===-1)throw new Error("JSONオブジェクトが見つかりません");let p=0,S=-1;for(let h=y;h<t.length;h++)if(t[h]==="{")p++;else if(t[h]==="}"&&(p--,p===0)){S=h;break}if(S===-1)throw new Error("JSONオブジェクトが不完全です");t=t.substring(y,S+1),u=JSON.parse(t)}catch(t){throw console.error("JSONパースエラー:",t),console.error("パースしようとしたテキスト:",d),t instanceof SyntaxError&&console.error("JSON構文エラー位置:",t.message),new Error(`APIレスポンスの解析に失敗しました: ${t instanceof Error?t.message:"Unknown error"}`)}if(!u.subTasks||!Array.isArray(u.subTasks))throw new Error("APIレスポンスの形式が正しくありません");const N=u.subTasks.map(t=>({name:t.name||"未命名タスク",urgency:Math.max(1,Math.min(4,parseInt(String(t.urgency))||2)),importance:Math.max(1,Math.min(5,parseInt(String(t.importance))||3)),contextKey:t.contextKey||"None",estimatedTime:Math.max(1,parseInt(String(t.estimatedTime))||30),keywords:Array.isArray(t.keywords)?t.keywords:[]}));return{parentTaskName:u.parentTaskName||a.substring(0,50),subTasks:N}};export{O as callGeminiAPI,E as getAvailableGeminiModels};
