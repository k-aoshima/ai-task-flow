(function() {
  const HOST_ID = 'ai-task-flow-notification-host';
  
  // Clean up existing notification if any
  const existingHost = document.getElementById(HOST_ID);
  if (existingHost) {
    existingHost.remove();
  }

  // Parse custom parameters from the injected script execution context if passed
  // However, chrome.scripting.executeScript arguments cannot easily pass dynamic complex objects to a file.
  // We will assume the caller sets a global variable or we use arguments.
  // Actually, simpler: The background script will inject code that sets a variable, THEN injects this file.
  // OR simpler: background script passes function with arguments.
  // Let's rely on the background script passing the data via `args` in executeScript.
  
  // NOTE: This file is designed to be injected via { files: ['notification-content.js'] }
  // To pass data, we can use a custom event or a global var set by a preceding injection.
  // BETTER STRATEGY: Define a function here, and let the background script call it? 
  // No, `scripting.executeScript` isolates contexts.
  
  // BEST STRATEGY: We will not use this file directly for the logic THAT DEPENDS ON DATA.
  // We will define the rendering logic here as a function, and the background script will execute a function that calls it.
  // wait, simplest is: Background script constructs the function call string? No, messy.
  
  // Let's use the `func` + `args` approach of `chrome.scripting.executeScript` instead of a separate file for the logic.
  // BUT, having a separate file for Styles/Structure is cleaner.
  
  // Alternative: Listener.
  // 1. Inject this script once (or ensure it's loaded).
  // 2. Send message to tab.
  // But we want to inject on demand.
  
  // Let's go with:
  // This file defines `window.showAiTaskFlowNotification = function(title, message) { ... }`
  // The background script: 
  // 1. Injects this file.
  // 2. Executes `window.showAiTaskFlowNotification(...)`.

  window.showAiTaskFlowNotification = function(title, message) {
    const host = document.createElement('div');
    host.id = HOST_ID;
    host.style.position = 'fixed';
    host.style.top = '20px';
    host.style.right = '20px';
    host.style.zIndex = '2147483647'; // Max Z-Index
    host.style.pointerEvents = 'none'; // Allow clicks through container
    document.body.appendChild(host);

    const shadow = host.attachShadow({ mode: 'open' });

    const container = document.createElement('div');
    container.style.cssText = `
      background: rgba(255, 255, 255, 0.95);
      backdrop-filter: blur(10px);
      border: 1px solid rgba(0, 0, 0, 0.1);
      border-radius: 12px;
      padding: 16px 20px;
      box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 10px 15px -3px rgba(0, 0, 0, 0.1);
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
      color: #1e293b;
      min-width: 320px;
      max-width: 450px;
      pointer-events: auto;
      display: flex;
      flex-direction: column;
      transform: translateX(120%);
      transition: transform 0.3s cubic-bezier(0.16, 1, 0.3, 1);
    `;
    
    // Dark mode support (basic detection from host page)
    if (window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches) {
       container.style.background = 'rgba(30, 41, 59, 0.95)';
       container.style.color = '#f8fafc';
       container.style.border = '1px solid rgba(255, 255, 255, 0.1)';
    }

    const header = document.createElement('div');
    header.style.cssText = `
      display: flex;
      align-items: center;
      gap: 8px;
      margin-bottom: 4px;
      font-weight: 600;
      font-size: 14px;
      color: #3b82f6;
    `;
    header.innerHTML = `<span>⏰ Time's Up!</span>`;

    const body = document.createElement('div');
    body.style.fontSize = '15px';
    body.style.lineHeight = '1.5';
    body.textContent = message;

    const closeBtn = document.createElement('button');
    closeBtn.textContent = 'OK';
    closeBtn.style.cssText = `
      margin-top: 12px;
      background: #3b82f6;
      color: white;
      border: none;
      padding: 8px 16px;
      border-radius: 6px;
      font-size: 13px;
      font-weight: 600;
      cursor: pointer;
      align-self: flex-end;
      transition: background 0.2s;
    `;
    closeBtn.onmouseenter = () => closeBtn.style.background = '#2563eb';
    closeBtn.onmouseleave = () => closeBtn.style.background = '#3b82f6';
    
    closeBtn.onclick = () => {
       container.style.transform = 'translateX(120%)';
       setTimeout(() => host.remove(), 300);
    };

    container.appendChild(header);
    container.appendChild(body);
    container.appendChild(closeBtn);
    shadow.appendChild(container);

    // Animate in
    requestAnimationFrame(() => {
      container.style.transform = 'translateX(0)';
    });

    // Auto dismiss after 15 seconds
    setTimeout(() => {
       if (document.body.contains(host)) {
          container.style.transform = 'translateX(120%)';
          setTimeout(() => host.remove(), 300);
       }
    }, 15000);
  };
})();
